PRODUCT BOOK - ANDROID READY PROJECT

This package contains the uploaded Product Book HTML wrapped as an Android WebView app.

Features from the supplied source:
- Product photo selection
- Product name, MRP, cost and selling price
- Automatic profit calculation
- Search
- Edit/delete
- CSV export
- Local storage

IMPORTANT:
This ZIP is an Android Studio project source package, not a precompiled APK.
To generate an APK, open/import the project in Android Studio or another Android build environment.
